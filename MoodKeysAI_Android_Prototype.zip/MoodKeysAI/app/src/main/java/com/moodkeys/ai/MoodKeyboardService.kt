package com.moodkeys.ai

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.inputmethod.EditorInfo

/** Minimal IME keyboard. It inserts text and offers a tap-to-preview mood suggestion. */
class MoodKeyboardService : InputMethodService() {
    private var typed = StringBuilder()
    private lateinit var hint: TextView

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(6, 8, 6, 8)
            setBackgroundColor(Color.rgb(24, 20, 43))
        }
        hint = TextView(this).apply {
            text = "🎧 Type a message; tap Suggest sound"
            setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
            setPadding(8, 10, 8, 10)
        }
        root.addView(hint, LinearLayout.LayoutParams(-1, -2))
        val suggest = Button(this).apply {
            text = "♫ Suggest sound"
            setOnClickListener {
                val s = MoodMatcher.suggest(typed.toString())
                hint.text = "${s.emoji} ${s.title} • ${s.mood} (demo suggestion)"
            }
        }
        root.addView(suggest, LinearLayout.LayoutParams(-1, -2))
        val rows = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
        rows.forEach { row ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            row.forEach { ch ->
                val b = Button(this).apply {
                    text = ch.toString(); textSize = 14f; setTextColor(Color.WHITE)
                    setPadding(0, 0, 0, 0); minWidth = 0; minimumWidth = 0
                    setBackgroundColor(Color.rgb(55, 45, 82))
                    setOnClickListener { currentInputConnection?.commitText(ch.toString(), 1); typed.append(ch) }
                }
                line.addView(b, LinearLayout.LayoutParams(0, 46, 1f).apply { setMargins(2, 2, 2, 2) })
            }
            root.addView(line)
        }
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun key(title: String, value: String, weight: Float = 1f) {
            val b = Button(this).apply {
                text = title; textSize = 12f
                setOnClickListener {
                    when (value) {
                        "SPACE" -> { currentInputConnection?.commitText(" ", 1); typed.append(' ') }
                        "DELETE" -> { currentInputConnection?.deleteSurroundingText(1, 0); if (typed.isNotEmpty()) typed.deleteCharAt(typed.length - 1) }
                        "ENTER" -> currentInputConnection?.performEditorAction(EditorInfo.IME_ACTION_DONE)
                        else -> { currentInputConnection?.commitText(value, 1); typed.append(value) }
                    }
                }
            }
            bottom.addView(b, LinearLayout.LayoutParams(0, 48, weight))
        }
        key("?123", "?123"); key("☺", "😂"); key("space", "SPACE", 3f); key("⌫", "DELETE"); key("↵", "ENTER")
        root.addView(bottom)
        return root
    }
}
