package com.moodkeys.ai

/** Simple offline keyword matcher for the prototype. Replace with an ML model/API later. */
object MoodMatcher {
    data class Suggestion(val mood: String, val title: String, val emoji: String, val hint: String)

    private val catalogue = listOf(
        Suggestion("Funny", "Comedy sting", "😂", "A short comic reaction"),
        Suggestion("Roast", "Dramatic roast", "💀", "A playful dramatic hit"),
        Suggestion("Sad", "Emotional piano", "🥲", "A soft, reflective sound"),
        Suggestion("Romance", "Romantic moment", "❤️", "A warm romantic cue"),
        Suggestion("Hype", "Victory energy", "🔥", "An energetic celebration"),
        Suggestion("Trending", "Viral-style beat", "🎬", "A short trend-inspired cue")
    )

    fun suggest(text: String): Suggestion {
        val s = text.lowercase()
        return when {
            listOf("idiot", "roast", "bro thinks", "clown", "skill issue", "💀").any(s::contains) -> catalogue[1]
            listOf("sad", "miss you", "heartbroken", "cry", "lonely", "😭").any(s::contains) -> catalogue[2]
            listOf("love you", "date", "cute", "beautiful", "❤️", "😘").any(s::contains) -> catalogue[3]
            listOf("won", "let's go", "lets go", "legend", "🔥", "hyped").any(s::contains) -> catalogue[4]
            listOf("haha", "lol", "lmao", "joke", "funny", "😂", "🤣").any(s::contains) -> catalogue[0]
            else -> catalogue[5]
        }
    }
}
