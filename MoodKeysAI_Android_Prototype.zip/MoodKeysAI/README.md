# MoodKeys AI — Android prototype (v0.1)

This is an early Android Studio project scaffold for the MoodKeys AI concept: a custom keyboard that suggests a sound based on the message being typed.

## Included
- Kotlin Android project structure
- Minimal custom input method (IME) keyboard
- Local keyword-based mood matching (funny, roast, sad, romance, hype, trending-style)
- Demo sound preview using a short system tone
- App screen for testing mood suggestions
- Keyboard settings shortcut

## Not included yet
- Real trending music or social-media scraping/integrations
- Audio imports or licensed music files
- A production AI model/API
- Sharing audio to the recipient inside a normal WhatsApp text message
- Release-ready APK or Play Store signing

## Open in Android Studio
1. Extract the ZIP.
2. Open the `MoodKeysAI` folder in Android Studio.
3. Allow Gradle sync and install the Android SDK requested by the project.
4. Run the app on an Android phone or emulator.
5. In the app, tap **Open keyboard settings**, enable **MoodKeys AI Keyboard**, then select it as the current keyboard.
6. Try the sample message in the app. In any text field, use the keyboard's **Suggest sound** button.

## Important prototype notes
- This is starter code and has not been built or tested on a device in this environment.
- The keyboard is deliberately minimal; the current suggestion matcher analyses only characters entered through its own keys, not text typed with another keyboard.
- Android IMEs can be used in many apps, but custom keyboards handle sensitive text. Keep processing transparent and local until there is a clear, consent-based reason to add a remote AI service.
- Use audio you own or are licensed to use. A social-media link does not automatically grant permission to extract or redistribute its audio.
